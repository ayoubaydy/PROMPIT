const fs = require("node:fs");
const path = require("node:path");
const vm = require("node:vm");

const imagePath = process.argv[2];
if (!imagePath) {
  console.error("Usage: node tests/live-ollama.test.js <image.png|jpg> [--focus=angle,lighting] [--platform=flux|qwen|chatgpt|nanobanana] [--enhancement=faithful|auto|professional|premium_ad] [--direction=contemporary_auto|source_match|cinematic_naturalism|editorial_tension|luxury_campaign|direct_flash|analog_tactile|sculptural_product|surreal_perspective|documentary_realism] [--strength=0..100] [--include-text] [--no-negative] [--no-refinement]");
  process.exit(1);
}

const bytes = fs.readFileSync(imagePath);
const extension = path.extname(imagePath).toLowerCase();
const mimeType = extension === ".png" ? "image/png" : extension === ".webp" ? "image/webp" : "image/jpeg";
const dimensions = readPngDimensions(bytes);
const chrome = {
  runtime: {
    onInstalled: { addListener() {} },
    onStartup: { addListener() {} },
    onMessage: { addListener() {} },
    async openOptionsPage() {}
  },
  action: { onClicked: { addListener() {} } },
  contextMenus: { onClicked: { addListener() {} }, removeAll() {}, create() {} },
  storage: { local: { async get() { return {}; }, async set() {} } },
  tabs: { async sendMessage() {} }
};

const context = vm.createContext({
  AbortController,
  URL,
  chrome,
  clearTimeout,
  console,
  crypto,
  fetch,
  setTimeout
});
const source = fs.readFileSync(path.join(__dirname, "..", "background.js"), "utf8");
vm.runInContext(`${source}\n;globalThis.__live = { callOllama, retryOllamaAnalysis, repairAnalysisJson, refineOllamaAnalysis, enhanceAnalysisPrompt, mergeAnalysisResults, normalizeAnalysis, tailorAnalysisToFocus, sanitizePromptOptions };`, context);

(async () => {
  const config = {
    ollamaBaseUrl: "http://127.0.0.1:11434",
    ollamaModel: process.argv.find((argument) => argument.startsWith("--model="))?.slice(8) || "qwen3.6:27b",
    customInstructions: "Prioritize exact camera geometry, perspective, and every visible light contribution.",
    promptEnhancementInstructions: "Use fluent professional production language while preserving every verified visual fact.",
    promptCreativeDirection: process.argv.find((argument) => argument.startsWith("--direction="))?.slice(12) || "contemporary_auto",
    promptCreativeLatitude: process.argv.find((argument) => argument.startsWith("--latitude="))?.slice(11) || "directed"
  };
  const image = {
    base64: bytes.toString("base64"),
    mimeType,
    width: dimensions.width,
    height: dimensions.height
  };
  const focus = process.argv.find((argument) => argument.startsWith("--focus="))
    ?.slice(8)
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean) || ["all"];
  const refinementStrength = Number(process.argv.find((argument) => argument.startsWith("--strength="))?.slice(11) || 50);
  const promptOptions = context.__live.sanitizePromptOptions({
    textMode: process.argv.includes("--include-text") ? "include_text" : "visuals_only",
    includeNegative: !process.argv.includes("--no-negative"),
    platform: process.argv.find((argument) => argument.startsWith("--platform="))?.slice(11) || "generic",
    enhancement: process.argv.find((argument) => argument.startsWith("--enhancement="))?.slice(14) || "professional",
    creativeDirection: process.argv.find((argument) => argument.startsWith("--direction="))?.slice(12) || "contemporary_auto",
    creativeLatitude: process.argv.find((argument) => argument.startsWith("--latitude="))?.slice(11)
      || (refinementStrength <= 30 ? "strict" : refinementStrength >= 71 ? "exploratory" : "directed"),
    refinementEnabled: !process.argv.includes("--no-refinement"),
    refinementStrength,
    learningEnabled: false,
    selectionMode: "full_image"
  });
  const mode = process.argv.find((argument) => ["--primary", "--retry", "--repair", "--refine"].includes(argument)) || "--primary";
  let verificationDraft = null;
  let raw = mode === "--retry"
    ? await context.__live.retryOllamaAnalysis(config, image, focus, promptOptions)
    : await context.__live.callOllama(config, image, focus, promptOptions);
  if (mode === "--repair") {
    raw = await context.__live.repairAnalysisJson(config, raw.slice(0, Math.ceil(raw.length * 0.55)), focus, promptOptions);
  }
  if (mode === "--refine") {
    let draft;
    try {
      draft = context.__live.normalizeAnalysis(raw);
    } catch {
      raw = await context.__live.retryOllamaAnalysis(config, image, focus, promptOptions);
      try {
        draft = context.__live.normalizeAnalysis(raw);
      } catch {
        draft = context.__live.normalizeAnalysis(await context.__live.repairAnalysisJson(config, raw, focus, promptOptions));
      }
    }
    verificationDraft = draft;
    raw = await context.__live.refineOllamaAnalysis(config, image, focus, promptOptions);
  }
  let result;
  try {
    result = context.__live.normalizeAnalysis(raw);
    if (verificationDraft) result = context.__live.mergeAnalysisResults(verificationDraft, result, focus, promptOptions);
    result = context.__live.tailorAnalysisToFocus(result, focus, promptOptions);
    if (promptOptions.enhancement !== "faithful") {
      result = await context.__live.enhanceAnalysisPrompt(config, result, focus, promptOptions);
    }
  } catch (error) {
    console.error("RAW RESPONSE:\n", raw.slice(0, 12000));
    throw error;
  }
  console.log(JSON.stringify({
    english: result.english,
    camera_angle: result.json.camera_angle,
    perspective_geometry: result.json.perspective_geometry,
    depth_of_field: result.json.depth_of_field,
    key_light: result.json.key_light,
    fill_ambient: result.json.fill_ambient,
    rim_backlight: result.json.rim_backlight,
    shadow_behavior: result.json.shadow_behavior,
    exposure_color_temperature: result.json.exposure_color_temperature,
    confidence_notes: result.json.confidence_notes,
    analysis_focus: result.json.analysis_focus || focus,
    prompt_options: result.json.prompt_options || promptOptions,
    target_platform: result.json.target_platform,
    prompt_creative_direction: result.json.prompt_creative_direction,
    prompt_style_decisions: result.json.prompt_style_decisions,
    prompt_visual_language_version: result.json.prompt_visual_language_version
  }, null, 2));
})().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});

function readPngDimensions(buffer) {
  const isPng = buffer.length >= 24 && buffer.subarray(1, 4).toString("ascii") === "PNG";
  return isPng
    ? { width: buffer.readUInt32BE(16), height: buffer.readUInt32BE(20) }
    : { width: 0, height: 0 };
}
