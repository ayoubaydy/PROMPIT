## Summary of Changes

Provide a brief summary of what this PR introduces or fixes.

## Type of Change

- [ ] Bug fix (non-breaking change fixing an issue)
- [ ] New feature (non-breaking change adding functionality)
- [ ] Breaking change (fix or feature causing existing functionality to change)
- [ ] Documentation update
- [ ] Code refactoring or performance optimization

## Verification & Testing

Describe the tests you ran to verify your changes:

- [ ] Ran `npm run lint` with 0 errors
- [ ] Ran `npm test` with 100% pass rate
- [ ] Ran `npm run build` and verified browser store zip packages
- [ ] Tested unpacked extension in Brave / Chrome / Edge / Firefox

## Checklist

- [ ] My code adheres to the project's coding standards.
- [ ] I have updated documentation / README as needed.
- [ ] Local-first privacy standards remain strictly intact.
- [ ] All tests pass locally.
