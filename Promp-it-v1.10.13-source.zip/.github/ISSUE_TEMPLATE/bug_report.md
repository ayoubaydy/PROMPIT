---
name: Bug report
about: Create a report to help us improve Promp it
title: '[BUG] '
labels: bug
assignees: ''
---

**Describe the bug**
A clear and concise description of what the bug is.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...'
2. Click on '...'
3. Scroll down to '...'
4. See error

**Expected behavior**
A clear and concise description of what you expected to happen.

**Environment (please complete the following information):**
 - OS: [e.g. Windows 11, macOS Sonoma, Ubuntu 24.04]
 - Browser: [e.g. Brave, Chrome, Edge, Firefox, Safari]
 - Browser Version: [e.g. 127.0]
 - Promp it Version: [e.g. v1.10.10]
 - Vision Provider: [e.g. Local Ollama (qwen3.6:27b), OpenAI Vision API]

**Additional context**
Add any other context or screenshots about the problem here.
