# Promp it — System, Conversation Decisions, and Prompt Enhancement

Document version: 1.7  
Product version: Promp it 1.10.13  
Last updated: 18 August 2026  
Runtime: Brave/Chrome Manifest V3 + local Ollama by default + optional OpenAI-compatible Vision API

## Document scope

This is the detailed product and engineering handoff for Promp it. It records:

- the product requirements and decisions established throughout the project conversation;
- the current extension architecture and data flow;
- the local Ollama model strategy for 6 GB, 12 GB, and higher-memory systems;
- the visual-analysis, verification, recovery, and prompt-enhancement pipeline;
- every user-facing analysis choice and settings control;
- local history, export, privacy, permissions, errors, and testing;
- the difference between factual image analysis and professional prompt writing.

This document describes Promp it's own system. It does not reproduce private platform, model-provider, or hidden assistant instructions.

## 1. Authoritative product definition

Promp it is a browser extension that turns a selected web image or captured page region into a detailed English image-generation prompt and structured JSON. Local Ollama is the default runtime; an optional OpenAI-compatible Vision API can be selected explicitly or used as a configured automatic fallback.

The extension supports three entry points:

1. Hover or keyboard-focus an eligible web image and select **Prompt image**.
2. Right-click an image and choose the Promp it context-menu command.
3. Start area capture from the toolbar, page context menu, or `Ctrl+Shift+P`, then drag around the desired region.

Before analysis, the user chooses what should be analyzed and how the answer should be formatted. Promp it then sends the selected pixels to the configured local Ollama server, performs a factual vision pass, verifies important reconstruction details against the image, optionally rewrites the verified facts into a professional prompt, and saves the result in local history.

Current non-negotiable product boundaries:

- Ollama is the private default inference provider.
- The optional external provider accepts only an OpenAI-compatible vision endpoint, model name, and API key supplied by the user. It never activates unless the user selects it or enables automatic fallback.
- No Gemini, Alibaba, cloud Qwen, hosted API, account, or API key is used.
- Arabic analysis and Arabic prompt generation are removed.
- Image pixels and prompts remain local unless the user deliberately points Ollama at a different server.
- Professional enhancement must not replace, reinterpret, or invent visual facts.
- The interface uses a restrained graphite liquid-glass treatment and a single consistent line-icon language.

## 2. Conversation-derived decision log

This section records the project conversation as product decisions rather than as a verbatim transcript.

### 2.1 Initial product reference

The first reference was a PromptCard-style extension with a compact floating prompt panel and a narrow image-history rail. The requested concept was:

- right-click any image and turn it into a detailed prompt;
- capture a custom page area and analyze it;
- describe subject, composition, style, lighting, colors, materials, mood, and other reconstructive details;
- copy prompts quickly;
- save images and prompts in local history;
- use a liquid-glass visual style;
- initially support English, Arabic, and JSON;
- initially consider Ollama, Gemini, and Qwen-related providers.

The current product retains the image workflow, detailed analysis, local history, JSON, and liquid-glass direction. Later decisions removed Arabic and all non-Ollama providers.

### 2.2 Image-level action

The extension needed an action displayed above images so users could generate a prompt without opening a separate popup. The result is a small **Prompt image** control revealed on image hover or keyboard focus.

### 2.3 Provider and connection failures

Early runs showed errors such as:

- `403 Forbidden`;
- `Failed to fetch`;
- provider not selected;
- prompts unrelated to the selected image.

The product was then explicitly narrowed to local Ollama only. The connection layer now:

- defaults to `http://127.0.0.1:11434`;
- calls Ollama's `/api/chat` and `/api/tags` endpoints;
- applies a narrowly scoped browser request rule for loopback Ollama URLs;
- removes the extension `Origin` header only for the configured local Ollama endpoints;
- presents specific connection, timeout, missing-model, invalid-JSON, and 403 messages.

### 2.4 Correct selected-image pixels

Unrelated prompt results indicated that an image URL could resolve to a placeholder, lazy-loaded asset, recycled DOM image, or another CDN resource. The capture path was changed to use the visible image element's actual rendered pixels whenever possible. Area capture similarly uses the exact selected page region.

### 2.5 Reconstruction accuracy

The initial generic description was not precise enough when used in image generators. The requested quality target expanded to cover:

- exact crop and aspect ratio;
- subject count and identity-neutral visible traits;
- pose, gesture, gaze, expression, head orientation, and body orientation;
- camera height, view, yaw, pitch, roll, and subject-relative angle;
- lens behavior without fabricated EXIF metadata;
- perspective convergence, vanishing behavior, foreshortening, edge distortion, and compression;
- focal plane, depth layers, focus falloff, blur, and bokeh;
- key, fill, ambient, rim, and backlight contributions;
- light direction, elevation, hardness, falloff, intensity, and color;
- cast-shadow direction, density, contact, length, and edge softness;
- exposure, highlight retention, white balance, and warm/cool relationships;
- spatial placement, overlap, scale, negative space, and visual hierarchy;
- materials, texture response, palette, mood, medium, and background.

Promp it now prefers a broad, visibly supported statement over false technical precision. It explicitly separates subject/head tilt from camera pitch and lens compression from camera distance.

### 2.6 Structured-output reliability

Ollama sometimes returned malformed or incomplete JSON. The pipeline was expanded to include:

1. a constrained primary JSON response;
2. a second image-aware retry when the primary response is malformed;
3. an automatic local structured-response repair when the retry remains malformed;
4. a separate image-aware verification pass for geometry and lighting;
5. tolerant parsing for fenced JSON, thinking blocks, and common trailing-comma failures;
6. graceful use of a valid primary result when verification fails.

### 2.7 Arabic removal

Arabic processing was explicitly removed to reduce unnecessary output, context usage, and repair complexity. The active result tabs are now:

- **EN** for the English prompt;
- **{ }** for structured JSON.

Old Arabic fields are removed when stored history is sanitized or migrated.

### 2.8 Local vision-model strategy

The product needed better vision prompting without being designed only for a high-end RTX 4090 system. The current practical tiers are:

| Approximate available memory | Preferred model | Runtime profile | Purpose |
| --- | --- | --- | --- |
| 6 GB | `qwen3.5:4b` | Compact | Smaller image and context budgets for accessible local use |
| 12 GB | `qwen3.5:9b` | Balanced | Better visual detail with moderate resource demand |
| 24 GB or more | `qwen3.6:27b` | Quality | Maximum supported reconstruction and prompt fidelity |

These figures are working targets, not guarantees. Quantization, GPU architecture, system RAM, VRAM, context length, CPU offload, and concurrent applications all affect actual memory use.

### 2.9 Focused analysis choices

The user needed to request only the technical domain relevant to the task rather than always generating a full description. The pre-analysis chooser now offers:

- All details;
- Subject;
- Pose;
- Camera;
- Angle;
- Composition;
- Lighting;
- Style & color;
- Background.

Selections can be combined. A focused result contains a small subject anchor and only the selected technical domains. For example, Angle does not inject unrelated style or lighting prose.

### 2.10 Text, negative prompts, and generator targets

The chooser also gained:

- **Visuals only**: ignore wording in the source and request no text, captions, typography, letters, logos, watermarks, or signatures;
- **Negative prompt**: include or omit image-specific mismatches and generation defects;
- **Target format**: Generic, Flux, Qwen Image, ChatGPT Images, or Nano Banana.

Negative terms are cleaned, deduplicated, limited to the chosen analysis domains, and checked so they do not contradict positive visible facts.

### 2.11 Professional prompt enhancement

The factual prompt was accurate but still less polished than a strong ChatGPT-written generation prompt. The supplied enhancement example emphasized language such as premium advertising, photorealistic luxury commercial photography, editorial direction, cinematic studio lighting, realistic highlights, dynamic composition, fine detail, and text/watermark exclusions.

The solution is a separate optional text-only refinement stage. It can turn a labeled or mechanically assembled reconstruction into a cohesive professional prompt while keeping verified facts authoritative.

Enhancement was deliberately moved out of the per-image chooser and into Settings so the main workflow stays focused on the image-specific request.

### 2.12 Final interface and workflow refinements

The latest requirements added:

- a redesigned Promp it capture-command logo;
- consistent Lucide-style line icons;
- a minimize control that collapses the dock into a corner restore pill;
- live elapsed analysis time and saved final generation time in seconds;
- automatic discovery of locally installed Ollama models;
- a native installed-model dropdown;
- a global professional-enhancement switch and treatment selector;
- separate editable analysis and refinement instructions;
- history export with the corresponding image and prompt for every entry.

These are implemented in Promp it 1.8.0.

### 2.13 Contemporary prompt intelligence

The next user evaluation found that accurate prompts could still generate visually dated work. Ollama could identify objects and lighting but did not consistently bring a broad, current understanding of cinematic treatments, editorial styling, perspective-led art direction, color science, or material finish.

Version 1.9 therefore adds a deterministic visual-language layer around the text-only refinement pass:

- a curated contemporary visual-system library rather than dependence on the model's training-era style vocabulary;
- ten selectable directions: source match, contemporary auto, cinematic naturalism, contemporary editorial tension, luxury campaign, direct flash, analog tactile, sculptural product, surreal perspective, and documentary realism;
- strict, directed, and exploratory creative latitude;
- one coherent core visual system and at most one compatible texture accent;
- a ban on trend-soup and empty quality tags such as “8K,” “masterpiece,” “ultra-detailed,” and unexplained “cinematic”;
- causal camera, perspective, lighting, material, and color decisions;
- platform-specific writing strategies for Generic, Flux, Qwen Image, ChatGPT Images, and Nano Banana;
- `prompt_creative_direction`, `prompt_style_decisions`, and `prompt_visual_language_version` metadata in structured history.

This makes current art direction a maintained product capability instead of hoping each local Ollama model already knows it.

### 2.14 Per-image refinement, selected-image crops, and local preference memory

The latest evaluation asked for refinement strength on the main workflow, true slide switches, a crop drawn inside the selected image, a visible prompting-active treatment, and a system that improves from use.

Version 1.10 implements these as explicit, bounded mechanisms:

- **Prompt refinement strength (0–100)** maps to source-locked (`0–30`), directed (`31–70`), and interpretive (`71–100`) behavior. The numeric value is also included in the text refinement instruction, so it changes how assertively the one selected visual system is written rather than merely changing a UI label.
- **Refine prompt** can bypass the text-only creative pass per image. Pixel analysis and verification still run.
- **Local learning memory** is a per-analysis switch backed by `prompitLearningMemory`. It is deliberately not described as retraining or fine-tuning Ollama. Copying a prompt is treated as an acceptance signal; repeated copies of the same history entry are ignored.
- Memory retains generalized weights for creative direction, target platform, analysis focus, accepted refinement strength, and safe craft signals such as motivated lighting, tactile texture, controlled palettes, spatial foreground staging, or material response. It does not store inferred identity or rewrite visible facts.
- At refinement time, up to two accepted direction preferences and three generalized craft signals are supplied as soft tie-breakers. The prompt explicitly states that pixels, selected focus, current controls, and verified facts outrank memory.
- **Select image area** activates only from an actual web-image action. The pointer rectangle is clamped to the visible bounds of that image. The resulting browser screenshot is cropped to exactly that rectangle before it reaches Ollama.
- The **animated dot-grid displacement** is functional feedback for image targeting and local processing. It is hidden before `captureVisibleTab`, restored only after the screenshot is complete, and rendered as a static field under `prefers-reduced-motion`.

These mechanisms refine the prompt-writing behavior while preserving the core evidence hierarchy: selected pixels first, current explicit controls second, accepted local preferences last.

### 2.15 Compact pre-analysis chooser

Version 1.10.1 keeps every per-image control but removes the long stacked setup sheet:

- **Focus** is the default panel and presents the nine analysis domains as a compact 3 × 3 Lucide icon matrix.
- **Output** contains the target generator, visuals-only handling, and negative-prompt choice. The selected-image crop control stays with **Focus**, where the user chooses what the vision pass should study.
- **Refine** contains the 0–100 strength slider, professional-refinement switch, and local-learning switch.
- Each tab exposes a live compact summary—selected focus count, target platform, or refinement value—without opening the panel.
- The current full configuration and Analyze action remain in a pinned footer while panel content can scroll independently on unusually short viewports.
- Tabs support click, touch, `Home`, `End`, and left/right arrow navigation. Focus is moved without scrolling the underlying page.

This is progressive disclosure rather than feature removal: only one decision group is visible at a time, while all analysis behavior and stored prompt options remain unchanged.

### 2.16 Post-generation background finishing and ZIP history export

The finished English prompt now has a compact **Finish prompt** strip so the user can make a safe, deterministic scene change after Ollama returns. It does not ask the vision model to reinterpret pixels or rerun a cloud/local inference request:

- **Keep scene** restores the detected source background and original English/generation prompt.
- **Replace background** removes sentence or semicolon clauses that explicitly refer to a background, backdrop, environment, surroundings, scenery, studio, seamless surface, wall, or floor, then appends the chosen replacement background.
- The background dropdown offers black solid, white solid, green solid, gray studio, cream studio, and editorial studio options.
- The original English prompt, original generation prompt, original background/environment fields, and selected preset are saved in the local history entry as `promptEdit`, so reopening history and export remains consistent.
- The strip only appears on **EN**. JSON remains a transparent view of the stored structured result, including the active `background_override` metadata.

History export now creates one user-requested ZIP. Each entry is placed in a numbered folder named by its prompt kind (`complete-prompt`, `angle-prompt`, `subject-style-prompt`, and so on), plus timestamp. A folder contains `image.<ext>` when a local source image remains available, `prompt.txt`, and `analysis.json`. ZIP creation uses local stored bytes; it does not send history to any service.

### 2.17 Spark identity, direct crop control, and post-result refinement

Version 1.10.3 introduced the two-star spark mark across the dock and Settings. The Settings marketing introduction was removed so configuration opens directly on the Ollama connection controls. Version 1.10.4 restores the cool graphite/cyan control accent, while prompts, headings, labels, and secondary copy use a neutral white-to-black scale. Cyan is reserved for iconography, focus, and selected controls rather than text.

The selected-image crop switch now lives directly below the default **Focus** matrix as **Analyze a crop**, keeping the image-specific targeting decision in the first/main workflow pane. It remains unavailable for page-wide area capture because there is no individual source image to crop.

After a result is generated, **Refine prompt** runs one additional Ollama text-only enhancement on that saved history entry. It does not upload or resend pixels. If the user has already chosen a replacement background, the original scene fields are used as the factual source for refinement, then the selected background is deterministically reapplied. This protects the edit while still allowing the professional pass to improve camera, light, perspective, material, and production language.

## 3. System architecture

### 3.1 Runtime components

| Component | Files | Responsibility |
| --- | --- | --- |
| Manifest | `manifest.json` | MV3 registration, permissions, content script, service worker, options page, command |
| Background service worker | `background.js` | Capture routing, pixel preparation, Ollama calls, JSON recovery, verification, enhancement, local prompt-finishing persistence, ZIP history export, context menus |
| Page interface | `content.js`, `content.css`, `tokens.css` | Spark-mark image action, focus chooser with direct crop option, refinement controls, image-contained area selector, dot-grid activation field, result dock, post-result refinement, background finishing capsules, minimize pill, timer, tabs, copy, history |
| Settings | `options.html`, `options.js`, `options.css` | Server URL, model discovery/selection, enhancement defaults, local learning-memory controls, analysis instructions, connection test, history controls |
| Preview harness | `preview.html`, `preview-mock.js`, `preview.css` | Local interaction and responsive visual testing without invoking Ollama |
| Tests | `tests/smoke.test.js`, `tests/live-ollama.test.js` | Payload/schema tests, model discovery, enhancement, export, and live local inference |

### 3.2 High-level data flow

```text
User selects image or page region
        |
        v
Exact visible pixels are captured and normalized
        |
        v
Focus + text mode + negative choice + platform + refinement controls are sanitized
        |
        v
Installed/selected local Ollama vision model receives image + strict schema
        |
        v
Primary JSON parse
   | valid                  | malformed
   v                        v
Continue              Image-aware retry
                            |
                      still malformed
                            v
                      Text-only JSON repair
        |
        v
Independent image-aware geometry/lighting verification
        |
        v
Verified fields are merged and narrowed to selected focus
        |
        v
Optional strength-scaled text-only enhancement + soft accepted-prompt preferences
        |
        v
Platform-specific formatting + negative sanitation
        |
        v
Display, local finishing, copy/acceptance signal, local history, optional ZIP export
```

### 3.3 Browser messages

The main internal message types are:

- `PROMPIT_ANALYZE_IMAGE`;
- `PROMPIT_CAPTURE_SELECTION`;
- `PROMPIT_SELECTION_CAPTURED`;
- `PROMPIT_CHOOSE_ANALYSIS_FOCUS`;
- `PROMPIT_START_CAPTURE`;
- `PROMPIT_START_IMAGE_AREA_SELECTION`;
- `PROMPIT_REQUEST_IMAGE_DATA`;
- `PROMPIT_RESOLVE_IMAGE`;
- `PROMPIT_STATUS`;
- `PROMPIT_RESULT`;
- `PROMPIT_GET_CONFIG`;
- `PROMPIT_SAVE_CONFIG`;
- `PROMPIT_LIST_MODELS`;
- `PROMPIT_TEST_OLLAMA`;
- `PROMPIT_OPEN_OPTIONS`;
- `PROMPIT_CLEAR_HISTORY`;
- `PROMPIT_DELETE_HISTORY`;
- `PROMPIT_EXPORT_HISTORY`;
- `PROMPIT_UPDATE_HISTORY_PROMPT`;
- `PROMPIT_REFINE_HISTORY_PROMPT`;
- `PROMPIT_RECORD_LEARNING`;
- `PROMPIT_GET_LEARNING_MEMORY`;
- `PROMPIT_RESET_LEARNING`.

## 4. Configuration system

Current stored configuration version: `9`.

```json
{
  "ollamaBaseUrl": "http://127.0.0.1:11434",
  "modelProfile": "auto",
  "ollamaModel": "qwen3.5:4b",
  "customInstructions": "",
  "promptEnhancementEnabled": true,
  "promptEnhancementPreset": "professional",
  "promptCreativeDirection": "contemporary_auto",
  "promptCreativeLatitude": "directed",
  "promptEnhancementInstructions": "",
  "promptLearningEnabled": true,
  "extensionEnabled": true,
  "configVersion": 9
}
```

Field meanings:

- `ollamaBaseUrl`: local Ollama server root.
- `modelProfile`: `auto` lets Promp it choose the strongest recognized installed vision model; manual/custom uses the exact dropdown selection.
- `ollamaModel`: active Ollama model tag.
- `customInstructions`: additional directions applied to the image-analysis stage; maximum 4,000 characters.
- `promptEnhancementEnabled`: global switch controlling the separate text-only refinement pass.
- `promptEnhancementPreset`: `professional` or `premium_ad`.
- `promptCreativeDirection`: selected visual system; `contemporary_auto` is the default.
- `promptCreativeLatitude`: `strict`, `directed`, or `exploratory`; `directed` is the default.
- `promptEnhancementInstructions`: optional creative direction for the refinement stage; maximum 2,400 characters.
- `promptLearningEnabled`: default state for per-image accepted-prompt preference memory.
- `extensionEnabled`: persistent global switch for all website interactions; false keeps configuration and history but removes or rejects every browser-page entry point.
- `configVersion`: migration marker.

Configuration is sanitized before use. Unknown provider fields, old Arabic fields, and obsolete cloud/API-key fields are not part of the current configuration.

## 5. Installed-model detection and selection

Settings calls the configured local Ollama `/api/tags` endpoint and builds a dropdown from the returned model list.

The detector records:

- model name;
- installed size;
- parameter size when Ollama reports it;
- quantization level when available;
- modification time;
- whether the name is likely to represent a vision-capable model;
- whether it appears in Promp it's preferred automatic priority list.

Name-based vision detection recognizes families such as:

- Qwen 3.5 and 3.6 multimodal releases;
- Qwen VL;
- LLaVA and BakLLaVA;
- Llama 3.2 Vision;
- Gemma 3;
- Moondream;
- MiniCPM-V;
- Granite Vision.

The label **vision likely** is advisory, not a guaranteed capability test. **Test Ollama** remains the authoritative readiness check.

Automatic priority currently prefers:

1. `qwen3.6:27b`;
2. `qwen3.5:27b`;
3. `qwen3.5:9b`;
4. `qwen3-vl:8b`;
5. `qwen3.5:4b`.

## 6. Image preparation

The analysis should describe the pixels the user selected, not a guessed remote asset.

For an image action, the content script obtains the visible element bounds and captures the rendered image. For area mode, the user drags a rectangular selection over the page. The background worker then prepares a normalized image while preserving:

- actual crop dimensions;
- approximate standard aspect ratio;
- portrait, landscape, or square orientation;
- enough resolution for the selected runtime profile.

Maximum prepared image side:

- Compact: 1,280 px;
- Balanced: 1,600 px;
- Quality: 2,048 px.

The dimensions are included in the vision instruction so crop and composition are not inferred without context.

## 7. Analysis-focus system

Default prompt options are:

```json
{
  "textMode": "visuals_only",
  "includeNegative": true,
  "platform": "generic",
  "enhancement": "professional",
  "creativeDirection": "contemporary_auto",
  "creativeLatitude": "directed",
  "refinementEnabled": true,
  "refinementStrength": 50,
  "learningEnabled": true,
  "selectionMode": "full_image"
}
```

Settings supplies the default treatment and direction. The main image chooser can enable or bypass refinement, set its strength, enable local memory for this analysis, and choose a full-image or selected-image-area crop. Main-flow controls are authoritative for that analysis and are saved in history.

Focus-to-field routing:

| Focus | Structured fields |
| --- | --- |
| Subject | `subject`, `subject_details` |
| Pose | `pose_expression` |
| Camera | `camera`, `depth_of_field`, `depth_layers` |
| Angle | `camera_angle`, `perspective_geometry` |
| Composition | `aspect_ratio`, `composition`, `spatial_layout`, `depth_layers`, `background` |
| Lighting | `lighting`, `key_light`, `fill_ambient`, `rim_backlight`, `shadow_behavior`, `exposure_color_temperature` |
| Style & color | `image_type`, `style`, `color_palette`, `materials`, `mood`, `background`, optionally `visible_text` |
| Background | `background`, `spatial_layout`, `color_palette`, optionally `visible_text` |

When **All details** is selected, every reconstructive domain is requested.

## 8. Structured visual-analysis contract

The primary response contains exactly two top-level fields:

```json
{
  "english": "Generator-ready English reconstruction prompt",
  "json": {
    "image_type": "",
    "aspect_ratio": "",
    "subject": "",
    "subject_details": "",
    "pose_expression": "",
    "composition": "",
    "spatial_layout": "",
    "camera_angle": "",
    "perspective_geometry": "",
    "depth_layers": "",
    "depth_of_field": "",
    "style": "",
    "lighting": "",
    "key_light": "",
    "fill_ambient": "",
    "rim_backlight": "",
    "shadow_behavior": "",
    "exposure_color_temperature": "",
    "camera": "",
    "mood": "",
    "background": "",
    "visible_text": "",
    "negative_prompt": "",
    "confidence_notes": "",
    "color_palette": [],
    "materials": []
  }
}
```

Focused schemas contain only the selected fields plus the minimum subject anchor required to keep the fragment usable.

Important field rules:

- `subject` and `subject_details` describe visible traits without inventing identity, nationality, occupation, brand, or biography.
- `camera_angle` separates subject orientation, camera elevation, yaw, pitch, and roll.
- `perspective_geometry` describes only visible convergence, horizon behavior, foreshortening, edge distortion, and compression.
- `camera` uses broad lens behavior such as wide, normal, or telephoto when supported; it does not invent camera bodies or exact focal lengths.
- `key_light`, `fill_ambient`, and `rim_backlight` are separated so multi-source lighting is not reduced to generic “cinematic light.”
- `confidence_notes` is empty when the evidence is clear and short when a detail is genuinely uncertain.
- `negative_prompt` contains likely contradictory deviations, not generic quality slogans.

## 9. Accuracy and verification system

### 9.1 Primary vision pass

The chosen vision model receives the image, crop dimensions, focus directive, text handling, negative-prompt rule, custom analysis instruction, and a strict JSON schema.

### 9.2 Structured retry and repair

If the response cannot be normalized:

1. Promp it retries with the original image and a tighter recovery schema.
2. If that is still malformed, a local repair call reconstructs valid JSON without adding new visual facts.
3. If a valid analysis already exists, later verification failure does not destroy it.

### 9.3 Independent visual verification

The verification pass is image-aware and is instructed to audit the pixels independently rather than trusting the first description. It checks the selected domains in a geometry-first order.

For full analysis, this includes:

- subject/object count and visible traits;
- pose, gaze, head/body orientation, and gesture;
- crop, placement, overlap, scale, and depth order;
- camera elevation, view, yaw, pitch, roll, and perspective cues;
- focus plane, blur, bokeh, and lens behavior;
- key, fill, ambient, rim/backlight, shadows, exposure, and color temperature;
- background, material response, palette, and visible text policy.

### 9.4 Conservative merge

Verified details replace or complete weak primary fields. Promp it then rebuilds the final factual prompt from the structured values. A professional rewrite happens only after this step.

## 10. Prompt enhancement in depth

### 10.1 Why enhancement is a separate stage

A vision model has two different jobs if asked for a polished prompt immediately:

1. inspect the image accurately;
2. write persuasive, fluent generation language.

Combining both jobs encourages generic style filler and can cause the model to “improve” the scene by changing it. Promp it therefore separates them:

- **Vision stage:** determine what is actually visible.
- **Enhancement stage:** rewrite those verified facts without seeing or reinterpreting the image.

The enhancement request is text-only. The verified factual prompt is treated as inert source data, not as an instruction that may override the system.

### 10.2 Enhancement modes

#### Faithful

No text-only Ollama rewrite is performed. Promp it assembles a direct reconstruction prompt from the selected verified fields and applies the target-platform wrapper.

Use this when:

- maximum literalness matters more than style;
- a smaller model struggles with long structured responses;
- the prompt will be edited manually;
- generation software responds better to terse tags.

#### Professional reconstruction

The text-only pass produces cohesive professional generation language integrating only supported details such as:

- subject and pose;
- framing and crop;
- camera elevation and subject view;
- lens behavior and perspective;
- foreshortening and depth compression;
- focal plane and depth of field;
- light direction, hardness, fill, rim, and shadows;
- material and skin response;
- palette, mood, and medium;
- spatial hierarchy and background.

The result should read as a deliberately authored production prompt, not a labeled field dump. It follows a causal production order:

1. purpose and scene;
2. subject and action;
3. composition, camera, and perspective;
4. lighting and material response;
5. palette, texture, and post finish;
6. fixed constraints.

#### Premium commercial campaign

This mode uses the same verified factual base but applies an authored campaign hierarchy when compatible with the subject and medium. It specifies refined material response, deliberate specular control, restrained palette, confident spatial hierarchy, credible texture, and an editorial finish. Generic glamour vocabulary is not enough.

It must preserve the observed crop, pose, geometry, lighting direction, palette, and material behavior. “Premium” is a production treatment, not permission to alter the image.

### 10.3 Creative-direction system

The enhancement stage receives one selected direction:

| Direction | Visible decisions it favors |
| --- | --- |
| Source match | Preserve the source's period, medium, contrast, color science, and texture; improve only clarity |
| Contemporary auto | Classify the verified image and choose one compatible current system from the internal library |
| Cinematic naturalism | Motivated sources, negative fill, highlight roll-off, atmospheric depth, observed composition |
| Contemporary editorial | Controlled asymmetry, sculptural crop, negative space, tactile surfaces, one point of tension |
| Luxury campaign | Refined material response, precise speculars, restrained palette, confident hierarchy |
| Direct-flash culture | Hard near-axis flash, crisp contact shadow, fast falloff, candid immediacy |
| Analog tactile | Organic grain structure, restrained bright-edge halation, dense color, subtle optical softness |
| Sculptural product | Graphic silhouette, gradient light, edge control, credible reflection/caustic behavior |
| Surreal perspective | One physically legible forced-scale, near-far, camera-height, deep-foreground, or compression device |
| Documentary realism | Available-light logic, lived-in context, unforced gesture, believable imperfection |

`contemporary_auto` can select from a broader internal vocabulary that also includes graphic mixed media and contemporary tactile CG. It must select one core visual system and no more than one compatible texture accent. Mixing unrelated styles is treated as a failure.

Creative latitude limits how far the rewrite may go:

- **Strict:** do not modernize or reinterpret source styling; improve technical and causal language only.
- **Directed:** preserve subject, pose, wardrobe, crop, scene layout, camera view, and visible light logic while modernizing compatible finish, color science, spatial energy, texture, and art direction.
- **Exploratory:** preserve subject/object count, pose, and core composition while allowing one clearly stated stronger interpretation of atmosphere, lighting treatment, palette, texture, or perspective emphasis.

The default is **Contemporary auto + Directed**.

### 10.4 Enhancement guardrails

The professional rewrite is instructed to:

- keep visible subject/object count unchanged;
- preserve anatomy, clothing, colors, materials, pose, expression, crop, and orientation;
- preserve camera angle, perspective relationships, light direction, shadow direction, and background;
- avoid exact focal length or camera-body claims without visible evidence;
- avoid identity, nationality, brand, and hidden-detail guesses;
- avoid turning eye-level into low angle;
- avoid turning frontal into three-quarter view;
- avoid turning subtle perspective into extreme distortion;
- distinguish head tilt from camera pitch;
- distinguish lens compression from camera distance;
- resolve conflicting factual phrases conservatively by keeping the broader supported description;
- keep the positive prompt under 320 words;
- keep the negative prompt under 80 words;
- return an empty negative field when negatives are disabled;
- enforce the text policy chosen by the user.

It also rejects vague prestige and trend tags unless each is converted into a visible decision. Perspective language must connect viewpoint to convergence, foreshortening, or near/far scale behavior and its compositional effect. Lighting language must connect source motivation and direction to apparent size/hardness, fill ratio, shadow/highlight behavior, and material response. Lens numbers are never invented; supported lens-family behavior is used instead.

If the model returns an unusable enhancement, Promp it falls back to a deterministic professional prefix and keeps the factual prompt instead of discarding the analysis.

### 10.5 Analysis instructions versus refinement instructions

The two editable instruction fields have different purposes.

**Analysis instructions** affect image inspection. Examples:

- prioritize architectural vanishing points;
- inspect every visible light source;
- pay special attention to hand pose;
- keep the final factual description under a chosen length.

These instructions cannot override visible evidence.

**Refinement direction** affects only the professional rewrite. Examples:

- use fashion-editorial language;
- prioritize exact camera height and forced perspective;
- emphasize material microdetail;
- keep a concise Flux-style sequence;
- never change detected wardrobe or pose.

Verified visual facts remain authoritative in both cases.

### 10.6 Negative-prompt processing

When enabled, negatives are assembled from:

- image-specific likely mismatches found during analysis;
- focus-appropriate exclusions;
- common generation defects when relevant;
- the standard no-text family when **Visuals only** is enabled.

Sanitation then:

- removes empty and meaningless entries;
- removes generic quality filler such as “8K,” “masterpiece,” or “stunning” from the negative list;
- removes duplicates;
- prevents negatives from excluding visibly affirmed facts;
- prevents “blurry background” from being excluded when shallow depth of field is positively requested;
- preserves visible text when text inclusion is enabled;
- limits focused analyses to negatives belonging to the selected domains.

### 10.7 Platform formatting

All platforms receive the same grounded facts. Only the outer instruction style changes.

| Platform | Formatting behavior |
| --- | --- |
| Generic | Direct positive prompt followed by `Exclude:` when negatives exist |
| Flux | Natural Subject + Action/Pose + Style + Context prompt; no negative-prompt channel. Essential exclusions become affirmative desired safeguards |
| Qwen Image | `Generate a visually precise image using this description:` and `Avoid these mismatches:` |
| ChatGPT Images | `Create an image with the following visual direction:` and `Do not include:` |
| Nano Banana | `Generate or edit the image to match this visual direction exactly:` plus an explicit instruction to preserve composition and visual relationships |

The platform selector does not change what the image contains. It changes how the same verified direction is communicated to the target generator. ChatGPT Images receives a concise production brief, Nano Banana receives fixed elements and spatial relationships before requested treatment, and Qwen receives explicit semantic-versus-appearance constraints.

### 10.8 Structured enhancement metadata

Successful text refinement adds:

- `prompt_enhancement: "ollama_text_refinement"`;
- `prompt_creative_direction`: one sentence naming the chosen system and its role;
- `prompt_style_decisions`: three to six concise causal decisions;
- `prompt_visual_language_version: "2026.09"`;
- `prompt_memory_used`: whether accepted local preferences supplied a useful soft directive;
- `prompt_memory_accepted_count`: the number of unique copied prompts represented in local memory;
- the final formatted `generation_prompt_en`.

## 11. Main panel and interaction system

### 11.1 Liquid-glass dock

The result interface is a dark graphite liquid-glass overlay designed to remain legible over arbitrary websites. It includes:

- redesigned Promp it wordmark and capture-command symbol;
- current version;
- minimize, history, settings, and close controls;
- image preview;
- analysis state and progress;
- elapsed/final generation time;
- English and JSON result tabs;
- copy action;
- local history rail.

### 11.2 Minimize and restore

Minimizing does not cancel Ollama. The full panel collapses into a corner pill containing:

- the Promp it symbol;
- product name;
- live `Working · N.N s` status during analysis;
- final `N.N s` duration after completion;
- restore action.

Closing the panel ends the visible session and resets the minimized state.

### 11.3 Generation timing

Timing begins when the loading state starts and updates every 100 ms. The service worker also records the complete request duration. Final history entries preserve `durationMs`, while the UI displays seconds to one decimal place.

### 11.4 Responsive behavior

The dock and settings were verified at 320, 375, 414, and 768 CSS pixels as well as desktop widths. Controls use a 44 px minimum target where visible. On narrow screens, the header compresses to the logo mark plus icon actions to prevent overlap.

### 11.5 Refinement slider and switch states

The Refine sheet includes a numeric 0–100 range with a value bubble, discrete track markers, and Exact/Interpretive endpoints. The native range remains keyboard operable and has a 44 px interaction height. Turning refinement off disables both the range and learning switch with visible, semantic disabled states. The Visuals only, Negative prompt, Analyze a crop, Refine prompt, and Local learning memory choices use one consistent slide-switch language.

### 11.6 Image-contained selection and prompting-active overlay

Image-contained selection is separate from whole-page area capture. The surface is positioned over the visible part of the chosen `<img>`, pointer coordinates are clamped to that rectangle, and selections smaller than 24 × 24 CSS pixels are rejected. Escape cancels.

The dot field uses transform/opacity-only displacement and pulse animation. It communicates targeting while dragging and local processing after capture. The overlay is made transparent for two animation frames before the screenshot request. The background worker then emits `PROMPIT_SELECTION_CAPTURED` after `captureVisibleTab` succeeds, allowing the processing field to reappear without contaminating the crop.

### 11.7 Local accepted-prompt memory

`prompitLearningMemory` stores:

- a schema version and unique accepted-entry IDs;
- accepted count and last-update time;
- weighted creative-direction, target-platform, and focus preferences;
- a running mean of accepted refinement strength;
- weighted generalized craft signals.

Learning occurs only after a successful clipboard copy from the English prompt tab and only when learning is enabled for that result. Copying JSON is not treated as prompt acceptance. The history ID makes the acceptance event idempotent. Settings shows the accepted count and provides an explicit reset. Clearing prompt history does not silently erase learned preferences; resetting memory is a separate user action.

## 12. Local history and export

Promp it keeps the latest 20 analyses in `chrome.storage.local`.

History metadata includes:

- unique entry ID;
- creation time;
- source URL;
- thumbnail preview;
- provider and model;
- selected focus;
- prompt options;
- generation duration;
- optional `promptEdit` source snapshot and selected background preset;
- English result;
- structured JSON.

Full normalized analyzed images are stored separately in `prompitHistoryImages`, keyed by history ID. Separating full images from the lightweight history list prevents every history render from loading all export-sized images.

### 12.1 Export layout

The user can export from the history rail or Settings. One locally built ZIP downloads, with each entry in a numbered, prompt-kind-named timestamped folder:

```text
Promp-it-history-YYYY-MM-DDTHH-MM-SS-Z.zip
  01-complete-prompt-YYYY-MM-DDTHH-MM-SS-Z/
    image.jpg
    prompt.txt
    analysis.json
  02-angle-prompt-YYYY-MM-DDTHH-MM-SS-Z/
    image.png
    prompt.txt
    analysis.json
```

`prompt.txt` contains:

- creation time;
- model;
- target platform;
- prompt kind and selected background finish when applicable;
- analysis focus;
- generation duration;
- source URL;
- finished English prompt.

`analysis.json` contains the structured visual result. New history entries export the normalized analyzed image. Older migrated entries fall back to the saved thumbnail when the full export image does not exist.

Deleting one history entry removes its associated full image. Clearing history removes both metadata and the separate image archive.

## 13. Privacy, permissions, and security boundaries

Manifest permissions and reasons:

| Permission | Reason |
| --- | --- |
| `activeTab` | User-triggered capture of the visible tab |
| `clipboardWrite` | Copy the generated prompt |
| `contextMenus` | Image and area-capture commands |
| `declarativeNetRequestWithHostAccess` | Remove the extension Origin header for configured loopback Ollama chat/model-list requests |
| `downloads` | Export image, prompt, and JSON files on user request |
| `storage` | Save settings and local history |
| `unlimitedStorage` | Retain the 20-entry normalized local image archive without Chrome's small default quota |
| `<all_urls>` host access | Add image controls and read user-selected images on normal websites |

Privacy behavior:

- Promp it does not contain API keys.
- Promp it does not call a cloud inference provider.
- Pixels go only to the configured Ollama URL.
- Settings and history are local and are not synced by Promp it.
- Accepted-prompt preference memory is local, identity-neutral, resettable, and never represented as Ollama weight training.
- Downloads occur only after an explicit export action.
- The Origin-removal rule is limited to `/api/chat` and `/api/tags` on a configured loopback URL.

## 14. Error handling

| Condition | User-facing behavior |
| --- | --- |
| Ollama unavailable / failed fetch | Ask the user to start Ollama and verify the local URL |
| 403 Forbidden | Ask the user to reload Promp it 1.10.4; if needed, check `OLLAMA_ORIGINS` or proxy rules |
| Missing selected model | Show the exact `ollama pull <model>` command |
| Model has no vision support | Explain that the selected model returned no image analysis and suggest another installed vision model |
| Timeout | Report that local Ollama did not respond within the model-specific time limit |
| Malformed JSON | Retry with image, repair locally, then show a concise structured-output error only if recovery fails |
| Verification failure | Preserve and use the valid primary result |
| Enhancement failure | Preserve the factual result and apply deterministic professional formatting |
| Empty history export | Explain that no local prompt history exists |
| Missing older full image | Export prompt/JSON and report the number of entries without full export images |

## 15. Runtime budgets

| Profile | Context | Primary output | Recovery output | Verification output | Max image side | Timeout |
| --- | ---: | ---: | ---: | ---: | ---: | ---: |
| Compact | 6,144 tokens | 2,100 | 1,900 | 2,100 | 1,280 px | 420 s |
| Balanced | 8,192 tokens | 2,600 | 2,200 | 2,600 | 1,600 px | 420 s |
| Quality | 12,288 tokens | 3,200 | 2,600 | 3,200 | 2,048 px | 480 s |

The professional text-only pass caps predicted output at the smaller of the verification budget and 2,200 tokens.

## 16. Verification record for version 1.10.4

The current build was verified with:

- JavaScript syntax checks for background, content, settings, preview mock, and live test files;
- manifest and Hallmark log JSON parsing;
- automated local payload smoke tests;
- model-list detection tests;
- professional enhancement tests confirming the refinement request contains no image payload;
- creative-direction, latitude, contemporary-library, causal-style-decision, and visual-language-version tests;
- refinement-strength threshold, per-analysis override, local-memory sanitation, signal classification, deduplication, and soft-directive tests;
- Flux tests confirming that negative prompts are replaced by affirmative safeguards;
- negative-prompt contradiction and duplicate sanitation tests;
- ZIP history export, prompt-kind naming, persisted background-finish tests, and post-result refinement preservation;
- a live local Ollama analysis with `qwen3.6:27b` on the supplied portrait reference;
- responsive browser QA at 320, 375, 414, and 768 px plus desktop;
- compact chooser verification covering Focus, Output, and Refine tabs, live tab summaries, pinned actions, keyboard navigation, the refinement range, slide switches, disabled states, and selected-image-area path;
- selected-crop verification confirming the dot-grid returns only after the screenshot is captured;
- minimize/restore, timer, and export-success interaction checks.

## 17. Current expected workflow

1. Load or reload the unpacked extension from `brave://extensions` or `chrome://extensions`.
2. Reload already-open website tabs.
3. Open Promp it Settings.
4. Confirm the local Ollama URL.
5. Detect installed models.
6. Choose automatic selection or an exact installed model.
7. Test Ollama.
8. Enable or disable Professional prompt refinement and local learning memory defaults.
9. Choose Art-directed reconstruction or Premium campaign reconstruction.
10. Select a creative direction and Strict, Directed, or Exploratory latitude.
11. Optionally add separate analysis and refinement instructions.
12. Hover an image, right-click it, or capture an area.
13. Choose the analysis focus, target platform, text mode, negative-prompt behavior, refinement strength, and local-memory state.
14. Optionally enable Select section, confirm, and draw a box inside the image.
15. Start analysis.
16. Minimize the panel if desired; the local request continues.
17. In English, keep the source scene or replace all background wording with a selected finish; copy the prompt to register an acceptance signal, or reopen it from history.
18. Export history as one prompt-kind-named ZIP when paired source images and prompts are needed.

## 17.1 Version 1.10.7 addendum — remembered setup and optional external vision

Version 1.10.7 preserves the compact chooser and adds three scoped behaviors:

1. **Remembered setup.** Promp it saves the last Focus selection, target platform, Visuals only rule, Negative prompt rule, refinement strength, and Select section mode in `chrome.storage.local` under `prompitLastPromptSetup`. Global enhancement direction, enablement, and learning preferences remain Settings-controlled, so an old per-image choice cannot silently override a later global configuration change.
2. **Select section.** The previous crop label is renamed to **Select section**. The control describes its real interaction: confirm the chooser, then draw a box on the visible image. The image-contained dot grid continues to mark targeting/processing and never enters the captured pixels. The in-panel load state now adds a compact halftone dot-wave above progress, using canvas rendering and a reduced-motion static fallback.
3. **Vision provider.** Settings exposes a progressive dropdown: `Ollama` (default), `Vision API`, or `Automatic`. The external branch is hidden until needed and asks for an OpenAI-compatible base URL, a vision-capable model, and an API key. The key is stored in extension-local browser storage. API mode sends the selected image data URL to the configured endpoint; Automatic tries Ollama first and uses the API only for an Ollama connection, timeout, or authorization failure. Both structured vision analysis and later text-only prompt refinement use the selected/fallback provider path.

The generic adapter requests Chat Completions-style vision messages with a base64 image data URL and prefers JSON Schema output, falling back to JSON object mode when the endpoint does not implement Structured Outputs. It is intentionally not advertised as compatibility with non-OpenAI-shaped APIs.

## 17.2 Version 1.10.8 addendum — evidence-first scan placement and responsive history

Version 1.10.8 tightens the panel behavior without changing the selected-pixel capture contract:

1. **Image-contained scan feedback.** The halftone canvas now sits over the preview of the image currently being analyzed. It appears only for the active request, follows the reduced-motion preference, and is cleared as soon as the result, error, or closed state arrives. The loading section now contains progress only; it no longer adds a separate decorative scan panel that could be mistaken for a second image or unrelated status screen.
2. **Expanded History uses the available prompt height.** On desktop widths where analysis and History are displayed side by side, the prompt output no longer has its normal fixed reading ceiling. Its scrollable region expands into the panel height shared by the History card, keeping long prompt language usable instead of leaving unused space below it. The compact single-panel behavior remains unchanged on narrow screens.
3. **Supplied app logo.** The analysis header, minimized dock, and Settings header use `PROMPIT_LOGO.svg` through the extension package. The SVG is declared as a web-accessible resource so the Shadow DOM panel can render it reliably on ordinary web pages.

## 17.3 Version 1.10.9 addendum — unified browser identity

Version 1.10.9 turns the supplied `PROMPIT_LOGO.svg` into a square, transparent PNG icon set at 16, 32, 48, and 128 pixels. `manifest.json` now declares those images at the extension level and for the browser action. This covers the toolbar, extension-management screen, installation surface, extension-page favicon, and context-menu identity while retaining the supplied SVG for the in-panel and Settings logos. PNG is deliberately used for these manifest fields because unpacked Chromium extensions do not accept SVG action or extension icons.

## 17.4 Version 1.10.10 addendum — source-evidence scan and compact progress

Version 1.10.10 makes the in-progress state describe the actual operation more honestly:

1. **Source-image scan overlay.** The halftone canvas is a fixed, non-interactive overlay aligned to the source `<img>` on the browser page, rather than a panel thumbnail. It tracks scrolling and resizing, uses the source image's corner radius, clears on completion, error, or close, and respects reduced-motion preferences. It starts only after Chromium has captured the source pixels, so the effect cannot become part of the pixel data passed to Ollama.
2. **Select section stays legible.** While a selected area is being processed, its original overlay no longer competes with the scan feedback. The target box remains as a quiet dashed boundary while its previous dots, instruction pill, backdrop, and dimming are hidden.
3. **Compact loading card.** Loading explicitly opts out of the analysis card's result-height floor. It contains only the image identity, elapsed time, progress, and disabled action rail, with no artificial blank region below the progress bar.
4. **Floating action treatment.** The browser-image **Prompt image** trigger now uses a restrained rotating conic glass edge around the existing graphite pill. Text remains neutral; cyan is limited to the spark mark and moving edge. The effect becomes static under reduced motion.

## 17.5 Version 1.10.11 addendum — website activation switch

Version 1.10.11 adds a single remembered activation boundary above provider setup. **Promp it on websites** defaults to enabled for every existing configuration. When saved as off, Promp it removes its image and area-capture context menus, changes the browser action title to make the dormant state clear, hides the page-level image action, closes any in-page dock or focus sheet, cancels current area selection, and rejects future analysis or capture requests before screenshot or inference work begins. Existing provider settings, custom instructions, learned preferences, and local history remain stored. Saving the switch back on restores context menus and lets all existing content scripts activate without requiring the user to reconfigure anything.

## 17.6 Version 1.10.12 addendum — toolbar menu controls

Version 1.10.12 makes the persistent browser action itself a control point. Right-clicking the Promp it toolbar icon provides a checked **Enable Promp it on websites** item, so it can be switched back on even after all website-level interface has been hidden. The same compact menu exposes the currently configured local/API/automatic model as a disabled status line, opens Settings directly, and opens the Baydy Art About page. Page-image actions remain absent when disabled; only the toolbar management controls stay accessible.

## 17.7 Version 1.10.13 addendum — outcome-led marketplace language

Version 1.10.13 changes product description language to communicate the user outcome before implementation detail: choose an image, let the selected vision model describe it in one click, and receive a complete image-generation prompt. The public copy explicitly names the subject, pose, camera, lighting, composition, material, and style evidence that can become part of that prompt. Local Ollama and optional compatible API configuration remain disclosed as supporting privacy/runtime detail, not the primary product promise.

## 18. Design principles for future changes

Future changes should preserve these rules:

- Exact selected pixels are more important than source URLs.
- Vision analysis and creative rewriting remain separate stages.
- Visual evidence always outranks custom instructions.
- Technical precision must be supported, not invented.
- A smaller local model must remain a first-class option.
- Model capability labels must be described as likely until tested.
- Per-image controls should describe the current task; global writing behavior belongs in Settings.
- Focused prompts should not leak unrelated domains.
- Negative prompts must not contradict positive facts.
- Platform formatting must not alter visual content.
- Local-first privacy boundaries and the explicit external-upload choice must remain clear.
- History exports should remain understandable without the extension installed.

## 19. Related project files

- `README.md` — installation, usage, troubleshooting, privacy, and concise version history.
- `ENHANCED EXAMPLE.MD` — user-supplied reference for the difference between plain analysis and professional generation language.
- `background.js` — authoritative analysis, verification, enhancement, model discovery, and export implementation.
- `content.js` / `content.css` — authoritative in-page interaction implementation.
- `options.html` / `options.js` / `options.css` — authoritative settings implementation.
- `manifest.json` — authoritative capabilities and permissions.
- `tests/smoke.test.js` — automated behavioral contract.
- `tests/live-ollama.test.js` — live local-model verification harness.
