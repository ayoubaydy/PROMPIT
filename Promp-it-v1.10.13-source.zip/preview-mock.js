(() => {
  const listeners = [];
  const store = {
    prompitConfig: {
      extensionEnabled: true,
      visionProvider: "ollama",
      ollamaBaseUrl: "http://127.0.0.1:11434",
      modelProfile: "auto",
      ollamaModel: "qwen3.6:27b",
      apiVisionBaseUrl: "",
      apiVisionModel: "",
      apiVisionKey: "",
      customInstructions: "",
      promptEnhancementEnabled: true,
      promptEnhancementPreset: "professional",
      promptCreativeDirection: "contemporary_auto",
      promptCreativeLatitude: "directed",
      promptEnhancementInstructions: "",
      promptLearningEnabled: true,
      configVersion: 10
    },
    prompitHistory: [],
    prompitLearningMemory: { version: 1, acceptedCount: 0, learnedEntryIds: [] }
  };

  const analysis = {
    english: "Eye-level frontal still life with a level camera and no roll: a pale sculptural vessel, diagonal cobalt plane, and small copper-red sphere in an asymmetrical frame with generous negative space; weak perspective convergence and neutral depth compression, all objects sharp with deep focus; a large soft key light arrives from upper image-left with gentle falloff, weak frontal fill, soft short shadows toward lower image-right, balanced exposure, neutral-warm white balance, matte paper textures, quiet editorial art direction, no visible typography.",
    json: {
      subject: "Abstract editorial still life with geometric forms",
      composition: "Asymmetrical, left-weighted arrangement with generous negative space",
      camera_angle: "Eye-level frontal view, level camera, no roll",
      perspective_geometry: "Weak convergence, neutral depth compression, no visible wide-angle distortion",
      depth_of_field: "Deep focus with all major objects sharp",
      style: "High-end editorial art direction and minimal studio photography",
      lighting: "Crisp side light with soft, controlled shadows",
      key_light: "Large soft source from upper image-left with gentle falloff",
      fill_ambient: "Weak frontal fill with low neutral ambient light",
      rim_backlight: "None",
      shadow_behavior: "Short soft-edged shadows cast toward lower image-right",
      exposure_color_temperature: "Balanced exposure, retained highlights, neutral-warm white balance",
      color_palette: ["warm cream", "cobalt blue", "copper red", "charcoal"],
      materials: ["matte paper", "painted plaster", "powder-coated metal"],
      camera: "Eye-level 50 mm lens language, medium-close framing",
      mood: "Quiet, tactile, precise",
      environment: "Minimal seamless studio set",
      typography: "No visible typography",
      negative_details: ["no glossy plastic", "no clutter", "no dramatic bloom"],
      generation_prompt_en: "Abstract editorial still life with matte geometric forms and crisp side light.",
      confidence_notes: "The material descriptions are visual estimates."
    }
  };

  window.chrome = {
    runtime: {
      getURL(path) { return new URL(path, window.location.href).href; },
      getManifest() { return { version: "1.10.13" }; },
      onMessage: { addListener(listener) { listeners.push(listener); } },
      async openOptionsPage() {},
      async sendMessage(message) {
        if (message.type === "PROMPIT_GET_CONFIG") return store.prompitConfig;
        if (message.type === "PROMPIT_GET_PROMPT_DEFAULTS") {
          const config = store.prompitConfig;
          return {
            promptEnhancementEnabled: config.promptEnhancementEnabled,
            promptEnhancementPreset: config.promptEnhancementPreset,
            promptCreativeDirection: config.promptCreativeDirection,
            promptCreativeLatitude: config.promptCreativeLatitude,
            promptLearningEnabled: config.promptLearningEnabled
          };
        }
        if (message.type === "PROMPIT_OPEN_OPTIONS") return { ok: true };
        if (message.type === "PROMPIT_GET_LEARNING_MEMORY") return { ok: true, memory: store.prompitLearningMemory };
        if (message.type === "PROMPIT_RESET_LEARNING") {
          store.prompitLearningMemory = { version: 1, acceptedCount: 0, learnedEntryIds: [] };
          return { ok: true };
        }
        if (message.type === "PROMPIT_RECORD_LEARNING") {
          if (!store.prompitLearningMemory.learnedEntryIds.includes(message.entryId)) {
            store.prompitLearningMemory.learnedEntryIds.push(message.entryId);
            store.prompitLearningMemory.acceptedCount += 1;
          }
          document.body.dataset.learningCount = String(store.prompitLearningMemory.acceptedCount);
          return { ok: true, memory: store.prompitLearningMemory };
        }
        if (message.type === "PROMPIT_LIST_MODELS") {
          return {
            ok: true,
            models: [
              { name: "qwen3.6:27b", visionLikely: true, recommended: true, parameterSize: "27B", quantization: "Q4_K_M", size: 16800000000 },
              { name: "qwen3.5:9b", visionLikely: true, recommended: true, parameterSize: "9B", quantization: "Q4_K_M", size: 6200000000 }
            ]
          };
        }
        if (message.type === "PROMPIT_EXPORT_HISTORY") {
          return store.prompitHistory.length
            ? { ok: true, entries: store.prompitHistory.length, files: store.prompitHistory.length * 3, missingImages: 0, archiveName: "Promp-it-history-preview.zip" }
            : { ok: false, error: "There is no local prompt history to export." };
        }
        if (message.type === "PROMPIT_UPDATE_HISTORY_PROMPT") {
          const index = store.prompitHistory.findIndex((entry) => entry.id === message.entryId);
          if (index < 0) return { ok: false, error: "That saved prompt is no longer in local history." };
          store.prompitHistory[index] = {
            ...store.prompitHistory[index],
            analysis: message.analysis,
            promptEdit: message.promptEdit
          };
          return { ok: true, entry: store.prompitHistory[index] };
        }
        if (message.type === "PROMPIT_REFINE_HISTORY_PROMPT") {
          const index = store.prompitHistory.findIndex((entry) => entry.id === message.entryId);
          if (index < 0) return { ok: false, error: "That saved prompt is no longer in local history." };
          const entry = store.prompitHistory[index];
          const refinedAnalysis = {
            ...entry.analysis,
            english: `${entry.analysis.english} Refined for clearer camera geometry, light direction, and material finish.`,
            json: {
              ...entry.analysis.json,
              generation_prompt_en: `${entry.analysis.json.generation_prompt_en || entry.analysis.english} Refined for clearer camera geometry, light direction, and material finish.`
            }
          };
          const refinedEntry = {
            ...entry,
            durationMs: 2190,
            promptOptions: { ...entry.promptOptions, enhancement: "professional", refinementEnabled: true },
            analysis: refinedAnalysis
          };
          store.prompitHistory[index] = refinedEntry;
          return {
            ok: true,
            analysis: refinedAnalysis,
            entry: refinedEntry,
            provider: "Ollama",
            focus: refinedEntry.focus,
            promptOptions: refinedEntry.promptOptions,
            durationMs: refinedEntry.durationMs
          };
        }
        if (message.type === "PROMPIT_RANDOMIZE_HISTORY_PROMPT") {
          const index = store.prompitHistory.findIndex((entry) => entry.id === message.entryId);
          if (index < 0) return { ok: false, error: "That saved prompt is no longer in local history." };
          const entry = store.prompitHistory[index];
          const randomStyle = {
            id: "soft_future_editorial",
            label: "Soft future editorial"
          };
          const randomizedAnalysis = {
            ...entry.analysis,
            english: `${entry.analysis.english} Reimagined with restrained spectral separation, modular framing, and tactile contemporary finish.`,
            json: {
              ...entry.analysis.json,
              generation_prompt_en: `${entry.analysis.json.generation_prompt_en || entry.analysis.english} Reimagined with restrained spectral separation, modular framing, and tactile contemporary finish.`,
              prompt_random_style: randomStyle.id,
              prompt_random_style_label: randomStyle.label
            }
          };
          const randomizedEntry = {
            ...entry,
            durationMs: 2840,
            promptOptions: {
              ...entry.promptOptions,
              enhancement: "professional",
              creativeDirection: randomStyle.id,
              creativeLatitude: "exploratory",
              refinementEnabled: true,
              refinementStrength: Math.max(70, Number(entry.promptOptions?.refinementStrength) || 0)
            },
            analysis: randomizedAnalysis
          };
          store.prompitHistory[index] = randomizedEntry;
          return {
            ok: true,
            analysis: randomizedAnalysis,
            entry: randomizedEntry,
            provider: "Ollama",
            focus: randomizedEntry.focus,
            promptOptions: randomizedEntry.promptOptions,
            durationMs: randomizedEntry.durationMs,
            randomStyle
          };
        }
        if (message.type === "PROMPIT_CLEAR_HISTORY") {
          store.prompitHistory = [];
          return { ok: true };
        }
        if (message.type === "PROMPIT_DELETE_HISTORY") {
          store.prompitHistory = store.prompitHistory.filter((item) => item.id !== message.id);
          return { ok: true };
        }
        if (message.type === "PROMPIT_CAPTURE_SELECTION" || message.type === "PROMPIT_ANALYZE_IMAGE") {
          if (new URLSearchParams(window.location.search).has("qa") && message.selection) {
            document.body.dataset.lastCapture = JSON.stringify(message.selection);
            document.body.dataset.lastFocus = JSON.stringify(message.focus || ["all"]);
            document.body.dataset.lastPromptOptions = JSON.stringify(message.promptOptions || {});
          }
          if (new URLSearchParams(window.location.search).has("providerError")) {
            return {
              ok: false,
              provider: "Ollama",
              error: "Ollama blocked this browser extension (403). Reload Promp it v1.10.13 and try again."
            };
          }
          if (message.selection && message.promptOptions?.selectionMode === "selected_area") {
            listeners.forEach((listener) => listener({
              type: "PROMPIT_SELECTION_CAPTURED",
              selection: message.selection,
              selectionMode: "selected_area"
            }, {}, () => {}));
          }
          await new Promise((resolve) => setTimeout(resolve, 900));
          const entry = {
            id: crypto.randomUUID(),
            createdAt: new Date().toISOString(),
            provider: "ollama",
            focus: message.focus || ["all"],
            promptOptions: message.promptOptions || {
              textMode: "visuals_only",
              includeNegative: true,
              platform: "generic",
              enhancement: "professional",
              creativeDirection: "contemporary_auto",
              creativeLatitude: "directed"
            },
            imagePreview: "demo-image.svg",
            durationMs: 12840,
            analysis
          };
          store.prompitHistory = [entry, ...store.prompitHistory].slice(0, 20);
          return {
            ok: true,
            analysis,
            entry,
            provider: "Ollama",
            focus: entry.focus,
            promptOptions: entry.promptOptions,
            durationMs: entry.durationMs
          };
        }
        return { ok: true };
      }
    },
    storage: {
      local: {
        async get(key) {
          if (typeof key === "string") return { [key]: store[key] };
          return { ...store };
        },
        async set(value) { Object.assign(store, value); }
      }
    }
  };

  window.addEventListener("DOMContentLoaded", () => {
    document.querySelector("#preview-capture")?.addEventListener("click", () => {
      listeners.forEach((listener) => listener({ type: "PROMPIT_START_CAPTURE" }, {}, () => {}));
    });

    const dispatch = (message) => listeners.forEach((listener) => listener(message, {}, () => {}));
    window.__prompitPreviewDispatch = dispatch;
    if (new URLSearchParams(window.location.search).has("result")) {
      const entry = {
        id: "preview-result",
        createdAt: new Date().toISOString(),
        provider: "ollama",
        focus: ["all"],
        promptOptions: {
          textMode: "visuals_only",
          includeNegative: true,
          platform: "generic",
          enhancement: "professional",
          creativeDirection: "contemporary_auto",
          creativeLatitude: "directed"
        },
        imagePreview: "demo-image.svg",
        durationMs: 12840,
        analysis
      };
      store.prompitHistory = [entry];
      dispatch({
        type: "PROMPIT_STATUS",
        state: "loading",
        progress: 74,
        label: "Auditing camera and light geometry…",
        imageUrl: "demo-image.svg",
        provider: "Ollama"
      });
      window.setTimeout(() => dispatch({
        type: "PROMPIT_RESULT",
        ok: true,
        analysis,
        entry,
        provider: "Ollama",
        promptOptions: entry.promptOptions,
        durationMs: entry.durationMs
      }), 180);
      if (new URLSearchParams(window.location.search).has("history")) {
        window.setTimeout(() => {
          document.querySelector("#prompit-extension-root")?.shadowRoot?.querySelector(".pi-history-toggle")?.click();
        }, 360);
      }
    }
  });
})();
